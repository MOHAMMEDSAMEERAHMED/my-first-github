// Reuse your background color function
function changeBackgroundColor() {
    const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    document.body.style.backgroundColor = randomColor;
}

// Fetch user data from API and update DOM
function fetchUserData() {
    fetch('https://jsonplaceholder.typicode.com/users')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('user-container');
            container.innerHTML = ""; // clear previous content

            data.forEach(user => {
                const userDiv = document.createElement('div');
                userDiv.style.border = "1px solid #ccc";
                userDiv.style.margin = "10px auto";
                userDiv.style.padding = "10px";
                userDiv.style.maxWidth = "400px";
                userDiv.style.backgroundColor = "#f9f9f9";

                userDiv.innerHTML = `
                    <h3>${user.name}</h3>
                    <p><strong>Email:</strong> ${user.email}</p>
                    <p><strong>City:</strong> ${user.address.city}</p>
                `;

                container.appendChild(userDiv);
            });
        })
        .catch(error => {
            console.error("Error fetching data:", error);
            document.getElementById('user-container').innerText = "Failed to load data.";
        });
}
