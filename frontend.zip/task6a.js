document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Stop page from reloading

    // Get values
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();

    const errorMsg = document.getElementById("error-message");
    const successMsg = document.getElementById("success-message");

    // Clear old messages
    errorMsg.textContent = "";
    successMsg.textContent = "";

    // Validation
    if (name === "" || email === "" || message === "") {
        errorMsg.textContent = "⚠️ All fields are required.";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        errorMsg.textContent = "⚠️ Please enter a valid email address.";
        return;
    }

    // If all is good
    successMsg.textContent = "✅ Thank you! Your message has been sent.";
    document.getElementById("contactForm").reset(); // Clear form
});
